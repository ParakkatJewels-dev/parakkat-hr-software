@echo off
REM Parakkat Attendance Sync - double-click to install or update (asks for administrator rights).
call "%~dp0deploy\windows\Install.bat"
