# Attendance service

BioTime sync worker + attendance engine + reporting API for Parakkat HRMS.

Attendance comes from ZKTeco face terminals. Those terminals are managed by **ZKTeco BioTime**,
and BioTime's REST API is the only integration surface — this service never touches the terminals
or BioTime's database directly.

```
ZKTeco terminals  ──►  BioTime (REST)  ──►  this service  ──►  Supabase Postgres  ──►  web app
                                             │
                                             ├── sync worker    every 2 min: punches → raw_punches
                                             ├── engine         punches + shift + leave → attendance
                                             └── API            recompute, exports, device mapping
```

## Why this exists as a separate service

The web app talks straight to Supabase, where Row-Level Security enforces the Role × Scope model.
That works for everything a *user* does. It cannot do the three things this service does:

1. **Run continuously.** Polling BioTime every two minutes needs a long-lived process.
2. **Work across all employees.** The engine must read and write every person's attendance, which
   is precisely what RLS is designed to prevent. It connects with the direct Postgres URL and
   bypasses RLS by design — a trusted background process with no user context.
3. **Generate Excel.** A 250 × 31 register with per-cell formatting is not a browser job.

Everything users read still goes through Supabase/PostgREST with RLS applied. The API here is
small, and each route declares the permission it requires (verified against the caller's Supabase
token — there is no second identity system).

## Setup

```bash
cd services/attendance
npm install
# .env ships in this folder pre-filled (gitignored). On a fresh git clone,
# copy it from the main machine — the sync cannot run without it.
npx prisma generate
npm run doctor                # verify everything before starting the worker
```

### Before the first run

Apply the pending migrations from `web/backend/supabase/migrations/`. The foundational `0012`–`0014` files create
`raw_punches`, `devices`, `biotime_employees`, `sync_state`, `sync_runs`, the shift and holiday
tables, leave types/balances, and regularizations — with RLS matching the rest of the schema.

The current worker also requires `0126_recompute_queue_generations.sql` before deployment. It
prevents a correction arriving during a rebuild from being acknowledged as already processed.
`0127_service_command_authority.sql` makes queued sync/backfill admission require the same global
device authority as execution. Apply both before restarting the updated worker; local tests do not
apply them to the hosted database.

```bash
cd ../../web/backend
# add SUPABASE_DB_URL to .env.local (Dashboard -> Connect -> Session pooler, port 5432)
npm run migrate
```

### `npm run doctor` — run this first

It answers, with real data, the two questions that quietly corrupt everything if assumed wrong:

- **What do BioTime `emp_code`s look like, and do they match `employees.employee_code`?**
  Almost certainly not — the roster importer generates employee codes from Excel row numbers
  (`PPI-0001`), while BioTime uses device enrolment numbers (`101`). See *Device code mapping* below.
- **Is the BioTime server's clock on the timezone `BIOTIME_TIMEZONE` claims?** BioTime returns
  naive local datetimes with no offset. If that box is on UTC while we parse as IST, every punch
  lands 5½ hours out and every downstream number is wrong.

## Environment

Full list with commentary inside `.env` itself. The ones that matter:

| Variable | Purpose |
|---|---|
| `DATABASE_URL` | Supabase **session pooler**, port 5432 (not 6543 — Prisma needs prepared statements) |
| `BIOTIME_BASE_URL` | e.g. `http://192.168.1.50:8090` |
| `BIOTIME_USERNAME` / `BIOTIME_PASSWORD` | BioTime API user |
| `BIOTIME_TIMEZONE` | Timezone the BioTime server reports punch times in. Verify with `npm run doctor` |
| `APP_TIMEZONE` | Business timezone, `Asia/Kolkata`. Timestamps are stored UTC and converted at the edges |
| `SYNC_TRANSACTIONS_CRON` | Punch poll, default every 2 minutes |
| `SYNC_EMPLOYEES_CRON` | Employee roster poll, default every 5 minutes; existing `.env` values override this |
| `SUPABASE_URL` / `SUPABASE_ANON_KEY` | Used to verify caller tokens on the API |

## Running

```bash
npm run dev        # worker + API, with reload
npm run build && npm start
```

In production use a supervisor — [ecosystem.config.cjs](ecosystem.config.cjs) for pm2 or
[deploy/parakkat-attendance.service](deploy/parakkat-attendance.service) for systemd.

```bash
npm run build
pm2 start ecosystem.config.cjs && pm2 save && pm2 startup
```

Run exactly **one worker** instance. Two workers would both run the cron schedule and double every
sync. API-only replicas do not reconcile work owned by the worker. During shutdown, scheduled,
startup and detached HTTP jobs are cancelled and drained before the database connection closes;
new detached requests receive 503 once shutdown starts.

## Commands

| Command | What it does |
|---|---|
| `npm run doctor` | Connectivity, timezone and code-mapping check. Start here |
| `npm run sync:once` | Pull new punches once |
| `npm run sync:employees` | Pull the BioTime roster + terminals, refresh match suggestions |
| `npm run sync:once -- --catchup --days 7` | Re-scan the trailing window for late uploads |
| `npm run backfill -- --from 2026-01-01 --to 2026-03-31` | Historical punches, in weekly chunks |
| `npm run backfill -- --from … --recompute` | …and run the engine over the range afterwards |
| `npm run recompute -- --month 2026-07` | Re-derive a month |
| `npm run recompute -- --from … --to … --employee <uuid>` | Re-derive one person |
| `npm run recompute -- --queue` | Drain pending corrections |
| `npm run seed` | Realistic fake punches so the frontend works without BioTime |
| `npm run test` | Rules, HTTP/authentication, scheduler and 503-employee calculation tests (isolated mocks; no database needed) |
| `npm run test:reports` | SQL and XLSX output checks for 503 employees in a disposable local PostgreSQL cluster |
| `npm run test:roles` | All seven standard roles through real HTTP/scoping/report SQL with migration-replayed access fixtures |
| `npm run test:engine` | Real recompute/queue SQL, concurrency, cancellation and 503-employee output in disposable PostgreSQL |

## How the sync stays correct

**Retries preserve stored punches and only advance the cursor after a complete run.** Three mechanisms work together:

- `raw_punches` has `unique (emp_code, punch_time)`, and every insert is `ON CONFLICT DO NOTHING`.
  Re-reading a window is therefore free.
- Each poll re-queries with a **5-minute overlap** before the cursor. Punches sharing a boundary
  second with the previous batch cannot fall through the gap.
- The cursor **advances only after a run completes**. A crash mid-run re-reads; it never skips.

Cancellation, exhausted page budgets, malformed successful HTTP responses and queue-write failures
now fail the run and preserve its cursor. A short server-capped page does not end ingestion while
the response still advertises more records. Cursor updates are atomic, so a stale overlapping run
cannot rewind the last successful position. Catch-up and backfill enqueue touched work dates and
the previous dates needed for overnight exits, just as incremental sync does.

Queued backfills use weekly windows and the historical-import page budget, matching direct HTTP
backfills. If a window still exceeds its page budget, it fails explicitly; reduce the window or
increase the configured budget before retrying. Previously stored punches remain safe to re-read.

Two failure modes are handled explicitly because they are not obvious:

- **Late uploads.** A terminal that loses its network stores punches locally and uploads them when
  it recovers — with their *original* punch time, already behind the cursor. The incremental poll
  structurally cannot see those, so a nightly catch-up re-scans the last few days.
- **BioTime restarts / 401s.** Both auth schemes are supported (`/api-token-auth/` with
  `Authorization: Token`, and `/jwt-api-token-auth/` with `Authorization: JWT`). The working one is
  probed once and cached. Any 401 triggers one re-authenticate-and-retry; transport failures back
  off exponentially with jitter.

## Device code mapping

### New employees from Easy Time Pro

Apply `0147_auto_provision_device_employees.sql` to enable automatic HR employee creation when
the worker receives a new active enrolment. This database migration also works with an existing
worker installation. It creates a basic employee record in the sole active company, uses the
device code as the HR employee code, and links previously unassigned punches for recomputation.
HR completes missing department, branch, payroll and personal details later. Existing HR fields,
manual mappings and ignored enrolments are preserved.

Possible duplicates, conflicting codes and deployments with multiple active companies stay in
the mapping queue for review. A name similarity score never merges two employees automatically.
Roster refreshes are idempotent, including after HR edits a provisioned employee's code.

The migration acts when roster data arrives; it does not contact Easy Time Pro itself. On the
Windows machine running the service, set `SYNC_EMPLOYEES_CRON="*/5 * * * *"` in `.env` and restart
the service. The updated Windows installer upgrades the previous daily default when rerun.
Until that configuration is updated, an existing daily schedule remains daily. A Git push or a
Vercel deployment does not restart this separate worker.

### Existing employees and mappings

**This is the step that makes the pipeline usable, and it needs a human once.**

BioTime `emp_code`s are device enrolment numbers. `employees.employee_code` is generated by the
roster importer from Excel row numbers. They do not correspond, so an exact-code join links
essentially nobody.

The roster sync therefore ranks candidates by name similarity (Dice coefficient over character
bigrams, blended with token overlap, nudged by department/area agreement) and stores them on
`biotime_employees.match_suggestions`. HR confirms them in **Attendance Setup → Devices & mapping**.

Only an exact, unambiguous code match auto-links. A fuzzy name score never does, however confident
it looks: a wrong auto-link files one person's attendance under another's name, which is far worse
than a code sitting in a queue. `manual` and `ignored` decisions are never overwritten by a later
sync.

Punches for an unmapped code are still stored — with a null `employee_id`, so they carry no
ancestry and are visible only to global-scope admins. Confirming the mapping afterwards adopts
every historical punch under that code and queues those dates for recompute.

## The engine

`processDay` is a pure function: no database, no clock, no I/O. That is what makes recomputing a
historical date produce the same answer today as it did last month, and what lets the rules be
tested without infrastructure (`npm run test`).

Given a date's punches, the assigned shift, the holiday calendar and any approved leave or
regularization, it derives check-in (first punch), check-out (last punch), worked minutes,
lateness, early exit, overtime, a status, and `day_fraction` — the payable credit (1, 0.5 or 0)
that payroll sums.

Edge cases handled explicitly:

- **Single punch day** → `Missing Punch`, credited 0.5 pending regularization. Not a zero-hour
  "Present", and not "Absent" either — the person demonstrably came in.
- **Night shift crossing midnight** → the punch window follows the shift into the next calendar
  day, so a 22:00–06:00 worker's morning exit is credited to the day they started.
- **Duplicate punches** → collapsed within `PUNCH_DEDUPE_SECONDS` (default 60). Without this, a
  double-tap on the reader can look like an 8-second working day.
- **No shift assigned** → `No Shift`, surfaced as an exception. Marking someone absent because
  nobody assigned them a shift would be an HR data problem masquerading as an attendance fact.

Adjacent effective-dated assignments share a single punch boundary. The usual cutover remains
six hours before the next shift starts; when a night-to-day rotation puts that time inside the
previous duty, the boundary moves to the midpoint of the gap between duties. Overlapping or
touching duties fail recomputation before attendance or leave changes are written. Single-day
and month-end recomputes load the neighbouring assignments too, so they produce the same result.

The `scheduled` break policy supports up to 16 paid or unpaid clock windows inside a shift,
including overnight breaks. Unpaid windows reduce only the overlapping attended time. Measured
time away outside all configured break windows is also deducted; paid break time is retained,
and unpaid time is never deducted twice. Missing break punches still raise an exception. The
existing fixed, actual, minimum-deduction and paid-allowance policies keep their prior behavior.

Apply `0164_shift_maintenance_safety.sql` before deploying this worker version: the loader reads
the new `shifts.break_windows` column. Restart the separate attendance worker after deployment;
deploying the web app alone does not update its calculations.

**Idempotent by contract.** Recomputing a range overwrites those rows cleanly, so rules can change
and history can be re-derived. Rows flagged `is_locked` (finalised payroll) are skipped unless
`--include-locked` is passed.

### Everything that changes an outcome triggers a recompute

Enforced by database triggers, not application code, so an approval from the UI, a script or the
SQL editor all behave identically. Approving leave, deciding a regularization, reassigning a shift,
editing a holiday or mapping a device code queues the affected employee-dates in
`attendance_recompute_queue`; the worker checks it every 2 minutes.

Future work remains queued until its date is due. Each repeated enqueue advances a generation;
the worker acknowledges only the generation it loaded. A correction arriving during computation
therefore survives for the next pass. Recompute calls serialize within this process, failed
regularization reads abort before replacing attendance, and explicit historical assignments retain
their shift rules even after that shift is deactivated. Continue to deploy one worker process.

Queued privileged commands recheck the requester's current grants at execution time. Malformed
dates and employee selections fail before work starts; cancelled work cannot overwrite an expired
command status with success. Binary export metadata records decoded file bytes.

## Reports

Both are generated server-side and stream straight to the browser.

- **Monthly attendance register** — per employee per day status grid, colour-coded, with totals.
  `GET /api/exports/register?year=2026&month=7`
- **Payroll export** — per employee for a month: days present, paid leave, LOP, payable days, OT.
  `GET /api/exports/payroll?year=2026&month=7&columns=employee_code,full_name,payable_days,ot_hours`

The payroll column layout is **configurable** because payroll formats are specific to whoever
processes them. Available columns come from `GET /api/exports/payroll/columns`; the catalog is in
[src/exports/columns.ts](src/exports/columns.ts) and adding a derived column means adding one
entry there.

Both reports retain employees who have attendance in the selected month even after they become
inactive. Multiple device enrolments produce one payroll row with all their codes. Half-day paid
leave and LOP are counted by their leave fractions, and overtime minutes are summed before rounding
to hours so the register and payroll agree.

An approved half-day of unpaid leave also caps the engine's payable credit at half a day, including
flexible shifts and reconstructed missing punches. The measured hours and attendance flags remain
available for review.

`npm run test:reports` requires `initdb` and `pg_ctl` on PATH. It creates a private cluster on a free
localhost port, inserts synthetic records, runs the actual report SQL, and saves/reopens both XLSX
formats to check their cells and totals. It ignores the configured database and removes the cluster
on completion. It does not start workers or contact BioTime.

`npm run test:engine` also requires local PostgreSQL tools. It verifies actual batch writes,
locked payroll rows, pre-hire cleanup, queue generations, loader failure, overlapping recomputes
and cancellation/retry against synthetic data. The root `npm run verify` includes it.

## API

Every route requires a valid Supabase access token and declares a permission.

| Route | Permission |
|---|---|
| `GET /health` | none — for the supervisor and uptime monitoring |
| `GET /api/status` | global `device.manage` / `attendance.manage` |
| `POST /api/sync/transactions`, `/employees`, `/catchup` | `device.manage` |
| `POST /api/backfill` | `device.manage` |
| `POST /api/recompute`, `/api/recompute/queue` | `attendance.manage` |
| `GET /api/mapping`, `POST /api/mapping/link`, `/suggest` | organisation-wide `device.manage` |
| `GET /api/exports/register`, `/payroll` | `report.read` / `attendance.read` |

Device roster requests accept `page` (starting at 1), `pageSize` (1–100, default 50), and an optional
link `status`. A paged request returns `{ rows, page, pageSize, total, pageCount }`. Omitting `page`
keeps the existing array response for older clients (up to 1,000 enrolments).

### Load controls

The API applies admission limits before expensive work:

| Budget | Limit |
| --- | --- |
| Incoming requests, before JSON parsing and Supabase session verification | 600 per client IP/minute; 1,800 per process/minute |
| Authenticated ordinary reads | 120 per user/minute |
| Authenticated ordinary writes | 30 per user/minute |
| Exports, syncs, backfills, recomputes and mapping suggestions, combined | 20 per user/minute |
| Expensive HTTP operations still running | 4 per process |
| Accepted background operations still running after HTTP 202 | 4 per process |

Excess requests receive HTTP **429** with a `Retry-After` duration in seconds. The header is
exposed to approved browser origins. Closing a browser connection does not free an expensive
operation's slot while its database/device work is still running. Quota maps hold at most 2,000
identities, expire after a minute, and refuse new identities at capacity instead of evicting an
active quota. These are process-local protections; running several workers multiplies capacity.
Use a shared ingress quota if the service is deployed across several processes or machines.

Client IPs come from the actual socket by default. When running behind a reverse proxy, configure
`API_TRUST_PROXY` with only that proxy's IP/CIDR (for example `127.0.0.1/32,::1/128` for a proxy on
the same machine). The default empty value ignores `X-Forwarded-For`; do not trust arbitrary
internet-supplied forwarding headers. Several devices behind one NAT share the IP budget but
keep independent authenticated user budgets.

Health database checks and global service diagnostics are cached in memory for **5 seconds**;
concurrent callers share one read. Every diagnostics request still passes its global permission
check before reading that cache. Session verification similarly shares concurrent requests for
the same token, uses at most 100 pending verifications, and has an 8-second timeout per upstream
request. Verified permissions are cached for at most **60 seconds**, never beyond the token's
expiry, with at most 2,000 entries. A permission change may therefore take up to one minute to
reach this service. Attendance/payroll reports are not response-cached; HTTP responses use
`private, no-store` to keep employee data out of browser/proxy caches.

These controls cover this Express service. The web app's direct Supabase Auth, PostgREST/RPC,
Storage and Realtime traffic, and the optional `invite-user` Edge Function, do not pass through
it. Their project/edge abuse controls must be managed at those platform entrypoints. The separate
developer integration API also has a shared PostgreSQL per-key quota; see
[Developer API](../../web/backend/DEVELOPER_API.md).

`npm run test:roles` uses the standard role grants and actual `get_my_access` payloads generated by
the web backend's disposable migration replay. It starts its own private PostgreSQL cluster and
Express server, checks scoped JSON and XLSX output and cross-branch/zone/company denials, and
captures the employee IDs passed to recompute. Supabase token verification and operational jobs are
fixtures, so the test neither contacts a real identity provider nor runs device synchronization.
Department and self grants deliberately cannot request bulk service exports; their regular scoped
application views remain governed by Supabase RLS. Detailed service diagnostics and device operations
require global authority because their payloads cannot be limited to one company or branch.

Security overrides keep Prisma 6, ExcelJS 4 and node-cron 3 while using patched `deepmerge-ts`,
`uuid` and `qs` releases. The callers use the unchanged `deepmerge` and UUID v4 APIs. Validate these
overrides with `npm audit`, `npm run prisma:generate`, `npm test` and `npm run test:reports` after
dependency changes.

`/health` returns **503** when the database is unreachable *or* the punch sync has not succeeded
for 30 minutes. The second condition is the one that matters operationally: the process can be
perfectly alive while silently collecting no attendance.

## Backups

[deploy/backup.sh](deploy/backup.sh) takes a verified daily `pg_dump`, keeps 14 dailies and 8
weeklies, and refuses to keep a dump it cannot read back.

**Restore procedure: [deploy/RESTORE.md](deploy/RESTORE.md).** Read it before you need it. The key
point: `public.attendance` is *derived* and can always be rebuilt from `raw_punches` with
`npm run recompute` — and punches themselves can be re-pulled from BioTime with `npm run backfill`.
Restoring from a dump is rarely the right first move.

## Troubleshooting

| Symptom | Where to look |
|---|---|
| No punches arriving | `npm run doctor`, then Attendance Setup → Sync status for the last error |
| Punches arriving, no attendance rows | Codes are probably unmapped — check Devices & mapping |
| Everyone marked Half Day on a shift | `full_day_minutes` exceeds what the shift allows after the break. The DB constraint now rejects this, but check existing shifts |
| Times out by 5½ hours | `BIOTIME_TIMEZONE` does not match the BioTime server's clock |
| Attendance looks stale | Check `attendance_recompute_queue` for a backlog, or run `npm run recompute -- --queue` |
| Worker restarting repeatedly | `pm2 logs parakkat-attendance`. Crash loops are usually bad credentials or an unreachable database |

Before applying migrations `0164`–`0165`, pause/stop the running attendance worker. Apply the migrations, deploy the updated worker, and only then restart it. This ensures the upgrade recomputation queue is consumed with the new punch-ownership rules. Wait for the queue to drain before regenerating payroll.

Migration `0165` requires an initial dated shift for every newly created employee, including trusted imports and automatic device provisioning. Trusted creation uses an active configured company/shared default when no shift is supplied; a missing default leaves device enrolments for HR review. The worker and SQL ownership resolver both exclude dates before a known joining date, so a new employee's initial early shift cannot overlap a hypothetical previous default night shift.
